"use strict";
exports.__esModule = true;
var Persona_1 = require("./Persona");
p1: Persona_1.Persona;
var objeto = new Persona_1.Persona(100);
objeto.caminar();
objeto.nombre;
console.log("hola soy una linea de JS dentro de tu TS");
//let var const
// var : es para variables globales 
// let es para variabels locales 
// var foo = 123 ;
// if (true){
//     var foo = 456;
// }
// console.log(foo); // 456
// let foo2 = 123 ;
// if (true){
//     let foo2 = 456;
// }
// console.log(foo2); // 123
//ES6 1995 MOCHA netscape  livescript javaScript
// 1997 TC39. ECMA diseña el estandar del DOM
var foo = 123;
console.log(foo);
//foo = 456;//no permitido !
//pero admiten ojetos literales 
var foo2 = {
    edad: 18,
    nombre: "alex"
};
//foo = {bar: 456} // NO permitido 
foo2.edad = 456;
console.log(foo2);
//tipos primitivos en TS
//boolean
var isDone = false;
//number
var decimal = 6;
console.log(decimal);
var hex = 0xf00d;
console.log(hex);
var binary = 10;
console.log(decimal);
var octal = 484;
console.log(octal);
//Cadenas de caracteres 
var color = "blue";
color = 'red';
//tambien se puede utilizar "templates" para concatenar 
var fullName;
var age = 37;
var sentence = "Hello , my name is " + fullName + ". I'll be " + (age + 1) + " years old next month";
console.log(sentence);
//esto seria equivalen a utilizar el mas "+"
var sentence2 = "Hello , my name is " + fullName + ". I'll be " + (age + 1) + " years old next month";
console.log(sentence2);
//atajos utiles 
//identado : alt + shift + f
// comentario : ctrl + k + c    o     ctrl + }
