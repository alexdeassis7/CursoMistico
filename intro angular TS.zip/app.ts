import { Persona } from "./Persona";

 p1: Persona ;
 var objeto = new Persona(100);
 objeto.caminar();
 objeto.nombre

console.log("hola soy una linea de JS dentro de tu TS");



//let var const

// var : es para variables globales 
// let es para variabels locales 


// var foo = 123 ;
// if (true){
//     var foo = 456;
// }
// console.log(foo); // 456


// let foo2 = 123 ;
// if (true){
//     let foo2 = 456;
// }
// console.log(foo2); // 123


//ES6 1995 MOCHA netscape  livescript javaScript
// 1997 TC39. ECMA diseña el estandar del DOM

const foo = 123;
console.log(foo);
//foo = 456;//no permitido !

//pero admiten ojetos literales 
const foo2 = {
    edad: 18,
    nombre: "alex"
}
//foo = {bar: 456} // NO permitido 

foo2.edad = 456;
console.log(foo2);

//tipos primitivos en TS

//boolean
let isDone: boolean = false;

//number
let decimal: number = 6;
console.log(decimal);


let hex: number = 0xf00d;
console.log(hex);


let binary: number = 0b1010;
console.log(decimal);

let octal: number = 0o744;
console.log(octal);

//Cadenas de caracteres 

let color: string = "blue";
color = 'red';

//tambien se puede utilizar "templates" para concatenar 

let fullName: `Bob Bobbington`;
let age: number = 37;
let sentence: string = `Hello , my name is ${fullName}. I'll be ${age + 1} years old next month`;
console.log(sentence);

//esto seria equivalen a utilizar el mas "+"
let sentence2: string = "Hello , my name is " + fullName + ". I'll be " + (age + 1) + " years old next month"
console.log(sentence2);
//atajos utiles 

//identado : alt + shift + f
// comentario : ctrl + k + c    o     ctrl + }








