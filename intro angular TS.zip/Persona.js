"use strict";
exports.__esModule = true;
exports.Persona = void 0;
var Persona = /** @class */ (function () {
    // metodos
    function Persona(kilometros) {
        this.kilometros = kilometros;
    }
    Persona.prototype.caminar = function () {
        console.log("estoy caminando para bajar la zapan ");
    };
    Persona.prototype.litrosDeBirratomadosElFinde = function () {
        return 8;
    };
    return Persona;
}());
exports.Persona = Persona;
