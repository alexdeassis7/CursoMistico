export class Persona {
    //atributos de la clase 
    nombre: string;
    apellido: string;
    edad: number;
    kilometros: number;

    // metodos
    constructor(kilometros: number) {
        this.kilometros = kilometros;
    }

    caminar() {
        console.log("estoy caminando para bajar la zapan ");
    }

    litrosDeBirratomadosElFinde(): number {
        return 8;
    }



}